Ronja Tetrapolis Housing v0.1

BY:
Twibright Labs http://ronja.twibright.com/tetrapolis/
Aziz Rasool
Mark
Roy Shearer

---------------------------------
CONTENTS
---------------------------------

Documentation:

* None

--------------------------------------------------

Physical:

* Ronja Tetrapolis Housing v0.2 2D Layouts [.dxf, .cdr]
* Ronja Tetrapolis Housing v0.2 3D Models [Solidworks 2004]

----------------------------------------------------

Updates from v0.1:

* Lens cap diameters updated to better fit lenses

--------------------------------------------------

Issues in this release:

* Lack of documentation.
* Assembly time of glueing on bosses to tube needs to be reduced.


---------------------------------
LICENSE
---------------------------------
   
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) 
http://creativecommons.org/licenses/by-sa/3.0/